package main

import (
	"fmt"
)

// Variável composta

func main() {
	
	var a, b, c, d, e string = "Carlos,", "Eduardo,", "João,", "Roberto,", "Josias"

	// Exibição do resultado
	fmt.Println(a, b, c, d, e)
}