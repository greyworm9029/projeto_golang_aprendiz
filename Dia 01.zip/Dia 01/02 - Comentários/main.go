// Comentário simples (de apenas uma linha): '//'

/* Esse é um comentário composto
   (com mais de uma linha).
*/